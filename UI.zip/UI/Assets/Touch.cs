﻿using UnityEngine;
using System.Collections;


public class Touch : MonoBehaviour {
	
	void Update()
	{
		if (Input.touchCount == 1)
		{
			Debug.Log ("Hey");
			Vector3 wp = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position);
			Vector2 touchPos = new Vector2(wp.x, wp.y);
			Debug.Log ("Hey");
			if (GetComponent<Collider2D>())
			{
				Debug.Log ("Touched");

			}
		}
	}
}